
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'gurushan',
  applicationName: 'auction-service',
  appUid: 'wxchSNSx3L3YpMpTwk',
  orgUid: 'e65d748e-e0bc-489e-89b8-fa9cc257b93f',
  deploymentUid: '40e453c0-edbe-4a2d-9bd3-c5dd5caf1268',
  serviceName: 'ci-cd-demo',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.4.8',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'ci-cd-demo-dev-hello', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}